#include <stdio.h>

int main(){
    printf("%lu", sizeof(int));
}