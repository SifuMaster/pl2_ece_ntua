#define ROWS 25
#define COLUMNS 80

void printTorus(char torus[ROWS][COLUMNS]);
