start server like this:

php -S localhost:8003

where you can replace 8003 with any available port you want
obviously index.php must be in the same directory
